import * as React from "react";
import { Frame, Point, Draggable, PropertyControls, ControlType } from "framer";

export interface Props {
  value: number;
  onValueChange: (value: number) => void;
  knob: string;
  track: string;
  tint: string;
  width: number;
  height: number;
  min: number;
  max: number;
  knobSize: number;
  shadow: number;
  trackHeight: number;
}

interface State {
  value: number;
}

export class Slider extends React.Component<Partial<Props>, State> {
  static defaultProps = {
    width: 120,
    height: 44,
    value: 50,
    knob: "white",
    track: "#DDD",
    tint: "#09F",
    min: 0,
    max: 100,
    knobSize: 28,
    shadow: "rgba(0,0,0,0.1)",
    trackHeight: 2,
  };

  static propertyControls: PropertyControls<Props> = {
    track: { type: ControlType.Color, title: "Track" },
    tint: { type: ControlType.Color, title: "Tint" },
    shadow: { type: ControlType.Color, title: "Shadow" },
    min: { type: ControlType.Number, title: "Min" },
    max: { type: ControlType.Number, title: "Max", max: 360 },
    value: { type: ControlType.Number, title: "Value", max: 360 },
    knobSize: { type: ControlType.Number, title: "Knob", min: 20, max: 50 },
    trackHeight: {
      type: ControlType.Number,
      title: "Height",
      min: 1,
      max: 10,
    },
  };

  state = {
    value: Slider.defaultProps.value,
  };

  componentDidMount() {
    const { value } = this.props;
    this.setState({ value });
  }

  componentWillReceiveProps(props: Props) {
    if (props.value !== this.props.value) {
      this.setState({ value: props.value });
    }
  }

  onMove = (event: Point) => {
    const { width, onValueChange, min, max } = this.props;
    const centerX = event.x + this.props.knobSize / 2;
    const value = Math.min(Math.max(min, (centerX / width) * max), max);
    this.setState({ value });
    if (onValueChange) {
      onValueChange(value);
    }
  };

  render() {
    const {
      knob,
      track,
      tint,
      width,
      height,
      min,
      max,
      knobSize,
      trackHeight,
    } = this.props;

    const value = Math.min(Math.max(this.state.value, min), max - knobSize / 2);
    const ratio = value / (max - min);
    const left = Math.round(width * ratio - this.props.knobSize / 2);

    const constraints = {
      x: 0,
      y: trackHeight / 2 - knobSize / 2,
      width: width,
      height: knobSize,
    };

    return (
      <>
        <Frame
          left={0}
          clip={true}
          height={this.props.trackHeight}
          width={width}
          top={(height - trackHeight) / 2}
          background={track}
          style={{ borderRadius: 50 }}
        >
          <Frame
            width={`${ratio * 100}%`}
            top={0}
            left={0}
            bottom={0}
            background={tint}
            style={{ borderRadius: 50 }}
          />
        </Frame>
        <Draggable
          width={this.props.knobSize}
          height={this.props.knobSize}
          constraints={constraints}
          bounce={false}
          overdrag={false}
          onMove={this.onMove}
          horizontal={true}
          vertical={false}
          left={left}
          top={height / 2 - this.props.knobSize / 2}
          background={knob}
          radius={"50%"}
          shadows={[
            {
              inset: false,
              color: `${this.props.shadow}`,
              x: 0,
              y: 1,
              blur: 2,
              spread: 0,
            },
            {
              inset: false,
              color: `${this.props.shadow}`,
              x: 0,
              y: 2,
              blur: 4,
              spread: 0,
            },
            {
              inset: false,
              color: `${this.props.shadow}`,
              x: 0,
              y: 4,
              blur: 8,
              spread: 0,
            },
          ]}
        />
      </>
    );
  }
}

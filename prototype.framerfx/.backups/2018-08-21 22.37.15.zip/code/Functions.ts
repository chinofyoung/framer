import { Override, Data } from "framer";

export const data = Data({
  grayscale: 0,
  contrast: 100,
  brightness: 100,
  hueRotate: 0,
  saturate: 100,
});

export const Effects: Override = props => {
  return {
    grayscale: data.grayscale,
    brightness: data.brightness,
    contrast: data.contrast,
    hueRotate: data.hueRotate,
    saturate: data.saturate,
  };
};

export const BrightnessValue: Override = props => {
  return {
    value: data.brightness,
  };
};

export const ConstrastValue: Override = props => {
  return {
    value: data.contrast,
  };
};

export const GrayScaleValue: Override = props => {
  return {
    value: data.grayscale,
  };
};

export const HueValue: Override = props => {
  return {
    value: data.hueRotate,
  };
};

export const SaturateValue: Override = props => {
  return {
    value: data.saturate,
  };
};

export const BrightnessSlider: Override = props => {
  return {
    onValueChange: (value: number) => {
      data.brightness = value;
    },
  };
};

export const ContrastSlider: Override = props => {
  return {
    onValueChange: (value: number) => {
      data.contrast = value;
    },
  };
};
//ben

export const GrayscaleSlider: Override = props => {
  return {
    onValueChange: (value: number) => {
      data.grayscale = value;
    },
  };
};

export const HueSlider: Override = props => {
  return {
    onValueChange: (value: number) => {
      data.hueRotate = value;
    },
  };
};

export const SaturateSlider: Override = props => {
  return {
    onValueChange: (value: number) => {
      data.saturate = value;
    },
  };
};
